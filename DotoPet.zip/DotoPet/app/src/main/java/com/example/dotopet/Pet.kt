package com.example.dotopet

data class Pet(
    val id: String = "",
    val nombre: String = "",
    val tipo: String = "",
    val raza: String = "",
    val edad: Int = 0,
    val fechaNacimiento: String = "",
    val peso: Double = 0.0,
    val proximaVacuna: String = ""
)