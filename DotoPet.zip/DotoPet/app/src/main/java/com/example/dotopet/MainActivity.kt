package com.example.dotopet

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var btnNuevoRegistro: Button
    private lateinit var btnVerMascotas: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnNuevoRegistro = findViewById(R.id.btnNuevoRegistro)
        btnVerMascotas = findViewById(R.id.btnVerMascotas)

        btnNuevoRegistro.setOnClickListener {
            startActivity(Intent(this, PetFormActivity::class.java))
        }

        btnVerMascotas.setOnClickListener {
            startActivity(Intent(this, PetListActivity::class.java))
        }
    }
}