package com.example.dotopet

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import android.util.Log

class PetFormActivity : AppCompatActivity() {

    private lateinit var tvTituloFormulario: TextView
    private lateinit var etNombre: EditText
    private lateinit var spinnerTipo: Spinner
    private lateinit var etRaza: EditText
    private lateinit var etEdad: EditText
    private lateinit var etFechaNacimiento: EditText
    private lateinit var etPeso: EditText
    private lateinit var etProximaVacuna: EditText
    private lateinit var btnGuardar: Button

    private val db = FirebaseFirestore.getInstance()
    private val tiposMascota = listOf("Perro", "Gato")

    private var petId: String? = null

    private val TAG = "DotoPetFirebase"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pet_form)

        enlazarVistas()
        configurarSpinner()
        cargarDatosParaEditar()

        btnGuardar.setOnClickListener {
            guardarMascota()
        }
    }

    private fun enlazarVistas() {
        tvTituloFormulario = findViewById(R.id.tvTituloFormulario)
        etNombre = findViewById(R.id.etNombre)
        spinnerTipo = findViewById(R.id.spinnerTipo)
        etRaza = findViewById(R.id.etRaza)
        etEdad = findViewById(R.id.etEdad)
        etFechaNacimiento = findViewById(R.id.etFechaNacimiento)
        etPeso = findViewById(R.id.etPeso)
        etProximaVacuna = findViewById(R.id.etProximaVacuna)
        btnGuardar = findViewById(R.id.btnGuardar)
    }

    private fun configurarSpinner() {
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            tiposMascota
        )

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerTipo.adapter = adapter
    }

    private fun cargarDatosParaEditar() {
        petId = intent.getStringExtra("pet_id")

        if (!petId.isNullOrEmpty()) {
            tvTituloFormulario.text = "Editar Mascota"
            btnGuardar.text = "Actualizar"

            etNombre.setText(intent.getStringExtra("pet_nombre"))
            etRaza.setText(intent.getStringExtra("pet_raza"))
            etEdad.setText(intent.getIntExtra("pet_edad", 0).toString())
            etFechaNacimiento.setText(intent.getStringExtra("pet_fecha_nacimiento"))
            etPeso.setText(intent.getDoubleExtra("pet_peso", 0.0).toString())
            etProximaVacuna.setText(intent.getStringExtra("pet_proxima_vacuna"))

            val tipo = intent.getStringExtra("pet_tipo") ?: "Perro"
            val posicion = tiposMascota.indexOf(tipo)

            if (posicion >= 0) {
                spinnerTipo.setSelection(posicion)
            }
        }
    }

    private fun guardarMascota() {
        val nombre = etNombre.text.toString().trim()
        val tipo = spinnerTipo.selectedItem.toString()
        val raza = etRaza.text.toString().trim()
        val edadTexto = etEdad.text.toString().trim()
        val fechaNacimiento = etFechaNacimiento.text.toString().trim()
        val pesoTexto = etPeso.text.toString().trim()
        val proximaVacuna = etProximaVacuna.text.toString().trim()

        if (nombre.isEmpty() || raza.isEmpty() || edadTexto.isEmpty() || pesoTexto.isEmpty()) {
            Toast.makeText(this, "Completa los campos obligatorios", Toast.LENGTH_SHORT).show()
            return
        }

        val edad = edadTexto.toIntOrNull()
        val peso = pesoTexto.toDoubleOrNull()

        if (edad == null || peso == null) {
            Toast.makeText(this, "La edad o el peso no son válidos", Toast.LENGTH_SHORT).show()
            return
        }

        btnGuardar.isEnabled = false

        if (petId.isNullOrEmpty()) {
            registrarMascota(nombre, tipo, raza, edad, fechaNacimiento, peso, proximaVacuna)
        } else {
            actualizarMascota(nombre, tipo, raza, edad, fechaNacimiento, peso, proximaVacuna)
        }
    }

    private fun registrarMascota(
        nombre: String,
        tipo: String,
        raza: String,
        edad: Int,
        fechaNacimiento: String,
        peso: Double,
        proximaVacuna: String
    ) {
        try {
            val documentRef = db.collection("mascotas").document()

            val mascota = Pet(
                id = documentRef.id,
                nombre = nombre,
                tipo = tipo,
                raza = raza,
                edad = edad,
                fechaNacimiento = fechaNacimiento,
                peso = peso,
                proximaVacuna = proximaVacuna
            )

            Log.d(TAG, "Intentando enviar mascota a Firebase: $mascota")

            documentRef.set(mascota)
                .addOnSuccessListener {
                    Log.d(TAG, "Mascota enviada correctamente a Firebase con ID: ${documentRef.id}")

                    Toast.makeText(
                        this,
                        "Se agrego exitosamente la mascota",
                        Toast.LENGTH_SHORT
                    ).show()

                    finish()
                }
                .addOnFailureListener { error ->
                    btnGuardar.isEnabled = true

                    Log.e(TAG, "Error al enviar la mascota a Firebase", error)

                    Toast.makeText(
                        this,
                        "Error al enviar la informacion a Firebase: ${error.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }

        } catch (e: Exception) {
            btnGuardar.isEnabled = true

            Log.e(TAG, "Error inesperado al registrar la mascota", e)

            Toast.makeText(
                this,
                "Error inesperado: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun actualizarMascota(
        nombre: String,
        tipo: String,
        raza: String,
        edad: Int,
        fechaNacimiento: String,
        peso: Double,
        proximaVacuna: String
    ) {
        try {
            val id = petId ?: return

            val mascota = Pet(
                id = id,
                nombre = nombre,
                tipo = tipo,
                raza = raza,
                edad = edad,
                fechaNacimiento = fechaNacimiento,
                peso = peso,
                proximaVacuna = proximaVacuna
            )

            Log.d(TAG, "Intentando actualizar mascota en Firebase: $mascota")

            db.collection("mascotas")
                .document(id)
                .set(mascota)
                .addOnSuccessListener {
                    Log.d(TAG, "Mascota actualizada correctamente en Firebase con ID: $id")

                    Toast.makeText(
                        this,
                        "Se actualizo la informacion",
                        Toast.LENGTH_SHORT
                    ).show()

                    finish()
                }
                .addOnFailureListener { error ->
                    btnGuardar.isEnabled = true

                    Log.e(TAG, "Error al actualizar la mascota en Firebase", error)

                    Toast.makeText(
                        this,
                        "Error al actualizar en Firebase: ${error.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }

        } catch (e: Exception) {
            btnGuardar.isEnabled = true

            Log.e(TAG, "Error inesperado al actualizar la mascota", e)

            Toast.makeText(
                this,
                "Error inesperado: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}