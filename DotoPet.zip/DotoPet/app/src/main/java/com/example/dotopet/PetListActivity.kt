package com.example.dotopet

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore
import android.util.Log

class PetListActivity : AppCompatActivity() {

    private lateinit var rvMascotas: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvSinRegistros: TextView
    private lateinit var petAdapter: PetAdapter

    private val db = FirebaseFirestore.getInstance()

    private val TAG = "DotoPetFirebase"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pet_list)

        rvMascotas = findViewById(R.id.rvMascotas)
        progressBar = findViewById(R.id.progressBar)
        tvSinRegistros = findViewById(R.id.tvSinRegistros)

        configurarRecyclerView()
    }

    override fun onResume() {
        super.onResume()
        cargarMascotas()
    }

    private fun configurarRecyclerView() {
        petAdapter = PetAdapter(
            pets = mutableListOf(),
            onEditClick = { pet ->
                abrirPantallaEdicion(pet)
            },
            onDeleteClick = { pet ->
                confirmarEliminacion(pet)
            }
        )

        rvMascotas.layoutManager = LinearLayoutManager(this)
        rvMascotas.adapter = petAdapter
    }

    private fun cargarMascotas() {
        progressBar.visibility = View.VISIBLE
        tvSinRegistros.visibility = View.GONE

        db.collection("mascotas")
            .get()
            .addOnSuccessListener { resultado ->
                val listaMascotas = mutableListOf<Pet>()

                for (documento in resultado) {
                    val mascota = documento.toObject(Pet::class.java)
                    listaMascotas.add(mascota.copy(id = documento.id))
                }

                petAdapter.actualizarLista(listaMascotas)

                tvSinRegistros.visibility = if (listaMascotas.isEmpty()) {
                    View.VISIBLE
                } else {
                    View.GONE
                }

                progressBar.visibility = View.GONE
            }
            .addOnFailureListener { error ->
                progressBar.visibility = View.GONE

                Toast.makeText(
                    this,
                    "Error al cargar mascotas: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }

    private fun abrirPantallaEdicion(pet: Pet) {
        val intent = Intent(this, PetFormActivity::class.java).apply {
            putExtra("pet_id", pet.id)
            putExtra("pet_nombre", pet.nombre)
            putExtra("pet_tipo", pet.tipo)
            putExtra("pet_raza", pet.raza)
            putExtra("pet_edad", pet.edad)
            putExtra("pet_fecha_nacimiento", pet.fechaNacimiento)
            putExtra("pet_peso", pet.peso)
            putExtra("pet_proxima_vacuna", pet.proximaVacuna)
        }

        startActivity(intent)
    }

    private fun confirmarEliminacion(pet: Pet) {
        AlertDialog.Builder(this)
            .setTitle("Eliminar mascota")
            .setMessage("¿Deseas eliminar el registro de ${pet.nombre}?")
            .setPositiveButton("Eliminar") { _, _ ->
                eliminarMascota(pet)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun eliminarMascota(pet: Pet) {
        if (pet.id.isEmpty()) {
            Toast.makeText(this, "No se puede eliminar: ID no valido", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            Log.d(TAG, "Intentando eliminar mascota en Firebase con ID: ${pet.id}")

            db.collection("mascotas")
                .document(pet.id)
                .delete()
                .addOnSuccessListener {
                    Log.d(TAG, "Mascota eliminada correctamente de Firebase con ID: ${pet.id}")

                    Toast.makeText(
                        this,
                        "Se elimino informacion exitosamente",
                        Toast.LENGTH_SHORT
                    ).show()

                    cargarMascotas()
                }
                .addOnFailureListener { error ->
                    Log.e(TAG, "Error al eliminar informacion en Firebase", error)

                    Toast.makeText(
                        this,
                        "Error al eliminar en Firebase: ${error.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }

        } catch (e: Exception) {
            Log.e(TAG, "Error inesperado al eliminar la mascota", e)

            Toast.makeText(
                this,
                "Error inesperado: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}