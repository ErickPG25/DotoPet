package com.example.dotopet

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PetAdapter(
    private val pets: MutableList<Pet>,
    private val onEditClick: (Pet) -> Unit,
    private val onDeleteClick: (Pet) -> Unit
) : RecyclerView.Adapter<PetAdapter.PetViewHolder>() {

    class PetViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNombreMascota: TextView = itemView.findViewById(R.id.tvNombreMascota)
        val tvTipoRaza: TextView = itemView.findViewById(R.id.tvTipoRaza)
        val tvDatosMascota: TextView = itemView.findViewById(R.id.tvDatosMascota)
        val tvVacuna: TextView = itemView.findViewById(R.id.tvVacuna)
        val btnEditar: Button = itemView.findViewById(R.id.btnEditar)
        val btnEliminar: Button = itemView.findViewById(R.id.btnEliminar)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PetViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pet, parent, false)

        return PetViewHolder(view)
    }

    override fun onBindViewHolder(holder: PetViewHolder, position: Int) {
        val pet = pets[position]

        holder.tvNombreMascota.text = pet.nombre
        holder.tvTipoRaza.text = "${pet.tipo} - ${pet.raza}"
        holder.tvDatosMascota.text = "Edad: ${pet.edad} años | Peso: ${pet.peso} kg"
        holder.tvVacuna.text = "Próxima vacuna: ${pet.proximaVacuna}"

        holder.btnEditar.setOnClickListener {
            onEditClick(pet)
        }

        holder.btnEliminar.setOnClickListener {
            onDeleteClick(pet)
        }
    }

    override fun getItemCount(): Int {
        return pets.size
    }

    fun actualizarLista(nuevaLista: List<Pet>) {
        pets.clear()
        pets.addAll(nuevaLista)
        notifyDataSetChanged()
    }
}